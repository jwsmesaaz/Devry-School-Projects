﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Net;
using System.Data;

namespace CIS407Project
{
    public class APInfusionsoft
    {
        public static dsPersonnel GetPersonnel(string Database, string strSearch)
        {
            //Initializes the dataset and Set to look at the dataset
            dsPersonnel DS = new dsPersonnel();
            //Initializes the SQL connection and Sets the connection so it will look at the correct database
            OleDbConnection sqlConn = new OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + Database);
            //Initializes the adapter
            OleDbDataAdapter sqlDA;

            //If statment for if there is information in the strSearch
            if (strSearch == null || strSearch.Trim() == "")
            {
                //Sets the SQL be be using the connection
                sqlDA = new OleDbDataAdapter("select * from tblPersonnel", sqlConn);
            }
            else
            {
                //Sets the SQL be be using the connection
                sqlDA = new OleDbDataAdapter("select * from tblPersonnel where " + strSearch, sqlConn);
            }

            //Gets the information from the dataset
            sqlDA.Fill(DS.tblPersonnel);

            //Returns what is in the dataset
            return DS;
        }
    }
}